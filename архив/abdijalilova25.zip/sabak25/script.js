//Данные

var names = prompt("Ваше имя?","");

var surname = prompt("Ваша фамилия?","");

console.log(names,surname);

//Сумма

var number_one =Number(prompt("Первое число?",""));

var number_two = Number(prompt("Второй число?",""));

var result = number_one+number_two;

alert(result);

//Умножение

var n_one =Number(prompt("Первое число умножение?",""));

var n_two = Number(prompt("Второй число умножение?",""));

var result = n_one*n_two;

alert(result);